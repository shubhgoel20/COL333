#!/bin/bash
#module load compiler/gcc/9.1.0
# Run the make command
make